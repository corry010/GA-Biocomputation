/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GeneticAlgorithm;



/**
 *
 */
import static GeneticAlgorithm.Ruleset1.*;
import static GeneticAlgorithm.StringData.*;
import static GeneticAlgorithm.Ruleset2.*;
import static GeneticAlgorithm.Ruleset3.*;
public class GA {

    static int RuleSet;
    static String[] DataRule, Condition, Output;
    static String DataString = "";
    //Comment out the selected "GettingRulesData1"// "GettingRulesData2"
    //Change the maximum gene length in the individual class - defaultGeneLength, 192 for dataset 1 and 448 for data set 2

    public static void main(String[] args) {
          RuleSet = 6; //Change this to 6/7 depending whether you're using data set 1,2 
         GettingRulesData1(); //data set 1
        //GettingRulesData2(); //data set 2
        //GettingRulesData3(); //data set 3

        Fitness.setSolution(DataString);
        System.out.print("Rules from data: ");//This prints out the Data Set 2 as rules
        for (int i = 0; i < DataRule.length; i++) {
            System.out.print(DataRule[i] + "  ");
           
        }
        System.out.println("");
        Populations myPop = new Populations(50, true);//50

        System.out.println("Random String " + myPop.getFittest()); //Prints out the random string generated

        //Declares the generation count to start at 0
        int generationsCounter = 0;

        // Evolve our population until we reach the solution
        //Keep repeating until the maximum fitness has been reached
        while (myPop.getFittest().getFitness() < Fitness.getMaxFitness()) { //While the fitness of the population is less than the maximum fitness declared in Fitness
            generationsCounter++; //Increment
            System.out.println("Generation: " + generationsCounter + " Fittness: " + myPop.getFittest().getFitness());
            for (int k = 0; k < myPop.individuals.length; k++) {
                for (int i = 1; i < myPop.individuals.length; i++) {
                    int j = i - 1;//static
                    if (myPop.individuals[j].getFitness() <= myPop.individuals[i].getFitness()) { //this should print out the correct gens
                        Individual temp = myPop.individuals[j];
                        myPop.individuals[j] = myPop.individuals[i];
                        myPop.individuals[i] = temp;
                    }
                }
            }

            for (int i = 0; i < myPop.individuals.length; i++) {
                System.out.print(myPop.individuals[i].getFitness() + " > ");
            }
            System.out.println("");

            System.out.println("The average fitness is: " + myPop.individuals[25].getFitness());
            System.out.println("The worst fitness is: " + myPop.individuals[49].getFitness());
            System.out.println("The best fitness is: " + myPop.individuals[1].getFitness());

            System.out.print("Rules from data:        ");
            for (int i = 0; i < DataRule.length; i++) {
                System.out.print(Condition[i] + " " + Output[i] + "  ");
            }

            System.out.println("");

            System.out.print("Rules for current gene: ");
            for (int j = 0; j < RandRule.length; j++) {
                System.out.print(ConditionForRandom[j] + " " + OutputForRandom[j] + "  ");
            }
            System.out.println("");

            myPop = GA_rates.evolvePopulation(myPop); //separate class for rate altering test fitness now
        }
        generationsCounter++;
        System.out.println("The correct solution has been found.");
        System.out.println("Fitness: " + myPop.getFittest().getFitness());
        System.out.println("Generations: " + generationsCounter);
        System.out.println("");
        //Printing out data and rules during testing data sets
        //System.out.println("Data : " + DataString);
        //System.out.println("Rules: " + myPop.getFittest());
        //now print out matched
        System.out.println("Data to match are: ");
        for (int i = 0; i < DataRule.length; i++)
        {
            System.out.print(Condition[i] + " " + Output[i] + " ");;
        }
        //print out matched rules
        System.out.println("Rules to match are: ");
        for (int i = 0; i < RandRule.length; i++)
        {
            System.out.print(ConditionForRandom[i] + " " + OutputForRandom[i] + " ");;
        }

    }
}

