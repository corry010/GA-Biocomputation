
package GeneticAlgorithm;


import java.util.Scanner;
import static GeneticAlgorithm.GA.*;



public class Ruleset3 {
     static String set3 = "";
     static String Datastring2 ="";


    static public void GetRulesData3(){



    }


}
